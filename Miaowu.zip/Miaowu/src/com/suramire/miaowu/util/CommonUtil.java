package com.suramire.miaowu.util;

import java.io.PrintWriter;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts2.ServletActionContext;


public class CommonUtil {
	private static PrintWriter out;
	/**
	 * 简化重复操作
	 * @param runnable 业务逻辑
	 */
	public static void  doSometing(final MyRunnable runnable){
		try {
			HttpServletResponse response = ServletActionContext.getResponse();
			response.setCharacterEncoding("UTF-8"); 
			out = response.getWriter();
			runnable.run(new OnResultListener() {
				
				public <T> void onSuccess(T data) {
					runnable.setResult(new BaseResponse<T>(200,"成功",data));
					
				}
				
				public void onFailure(String failureMessage) {
					runnable.setResult(new BaseResponse<Object>(0,failureMessage,null));
					
				}
				
				public void onError(String errorMessage) {
					runnable.setResult(new BaseResponse<String>(-1,"发生异常",errorMessage));
					
				}
			});
		} catch (Exception e) {
			runnable.setResult(new BaseResponse<String>(-1,"发生异常",e.getMessage()));
			e.printStackTrace();
		} finally{
			String mString = GsonUtil.objectToJson(runnable.getResult());
			out.print(mString);
			out.flush();
			out.close();
		}
	}

	/**
	 * 判断字符串是否是手机号格式
	 * @param mobiles 待验证的号码
	 * @return true表示是手机号
	 */
    public static boolean isMobileNumber(String mobiles) {
        return Pattern.compile("^((13[0-9])|(15[^4,\\D])|(18[^1^4,\\D]))\\d{8}").matcher(mobiles).matches();
    }
    
    /**
     * 得到当前时间戳
     * @return
     */
    public static Timestamp getTimeStamp(){
        return new Timestamp(new Date().getTime());
    }

    /**
     * 时间戳转成日期字符串
     * @param timestamp
     * @return
     */
    public static String timeStampToDateTimeString(Timestamp timestamp){
        SimpleDateFormat sSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        return sSimpleDateFormat.format(timestamp);
    }

}
