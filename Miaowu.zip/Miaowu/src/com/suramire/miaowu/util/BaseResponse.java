package com.suramire.miaowu.util;

/**
 * Created by Suramire on 2018/1/23.
 * 响应结构 包含状态码、状态文字以及携带数据
 */

public class BaseResponse<T> {
    public int code;
    public String message;
    public T data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
    
    public BaseResponse() {
    
    }

    public BaseResponse(int code, String message, T data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }
}
