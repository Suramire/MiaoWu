package com.suramire.miaowu.util;


import java.util.ArrayList;
import java.util.List;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

/**
 * JSON 相关操作类
 */
public class GsonUtil{
	/**
	 * 将对象转换成JSON字符串
	 * @param obj 对象
	 * @return JSON字符串
	 */
	public static String  objectToJson(Object obj){
		return new GsonBuilder().setPrettyPrinting().create().toJson(obj);
	}
	/**
	 * 将存放对象的List转换成JSONArray字符串
	 * @param <E> Object
	 * @param lists 存放对象的List
	 * @return JSONArray字符串
	 */
	public static <E> String objectToJsonArray(List<E> lists){
		return new GsonBuilder().setPrettyPrinting().create().toJson(lists);
	}
	/**
	 * 解析JSON成对象
	 * @param <T> 泛型
	 * @param jsonString 源JSON字符串
	 * @param cls 目标对象的类
	 * @return 对象
	 */
	public static <T> Object jsonToObject(String jsonString,Class<T> cls){
		Gson gson = new Gson();
		T fromJson = gson.fromJson(jsonString, cls);
		return fromJson;
	}
	
    /**
     * 根据json字符串获取响应对象的List
     * @param jsonString json字符串
     * @param tClass 需要装换的对象
     * @param <T> 泛型
     * @return List
     */
    public static  <T> List<T> jsonToList(String jsonString, final Class<T> tClass ){
        Gson gson = new Gson();
        List<T> list = new ArrayList<T>();
        try{
            JsonArray array = new JsonParser().parse(jsonString).getAsJsonArray();
            for(final JsonElement elem : array){
                list.add(gson.fromJson(elem, tClass));
            }
        }catch (Exception e){
            System.out.println("err:"+"jsonToList: "+e);
        }
        return list;
    }
    
	
}
