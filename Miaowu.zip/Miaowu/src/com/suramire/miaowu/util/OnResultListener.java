package com.suramire.miaowu.util;

/**
 * 
 * @author Suramire
 * @since 2018-04-21
 * 
 * 响应体监听器
 *
 */
public interface OnResultListener {
	<T> void onSuccess(T data);
	void onFailure(String failureMessage);
	void onError(String errorMessage);
}
