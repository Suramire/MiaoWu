package com.suramire.miaowu.util;

public class MyRunnable implements Runnable {
	
	private BaseResponse<?> mResponse;
	
	
	public BaseResponse<?> getResult() {
		return mResponse;
	}

	public void setResult(BaseResponse<?> mResult) {
		this.mResponse = mResult;
	}

	
	public void run(OnResultListener listener) {
		
	}

	public void run() {
		
		
	}


}
