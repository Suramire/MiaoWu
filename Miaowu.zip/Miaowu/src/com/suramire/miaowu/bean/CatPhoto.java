package com.suramire.miaowu.bean;

/**
 * CatPhoto entity. @author MyEclipse Persistence Tools
 */

@SuppressWarnings("serial")
public class CatPhoto implements java.io.Serializable {

	// Fields

	private Integer id;
	private Integer cid;
	private String name;

	// Constructors

	/** default constructor */
	public CatPhoto() {
	}

	/** full constructor */
	public CatPhoto(Integer cid, String name) {
		this.cid = cid;
		this.name = name;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCid() {
		return this.cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

}