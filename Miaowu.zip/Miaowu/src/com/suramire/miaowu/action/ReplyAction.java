package com.suramire.miaowu.action;

import java.io.Serializable;

import com.suramire.miaowu.bean.Reply;
import com.suramire.miaowu.dao.ReplyDAO;
import com.suramire.miaowu.dao.UserDAO;
import com.suramire.miaowu.util.CommonUtil;
import com.suramire.miaowu.util.GsonUtil;
import com.suramire.miaowu.util.MyRunnable;
import com.suramire.miaowu.util.OnResultListener;

/**
*
* @author Suramire
* 
* 评论相关操作
*
*/

public class ReplyAction {
	
	ReplyDAO replyDAO;
	UserDAO userDAO;
	String jsonString;
	public ReplyDAO getReplyDAO() {
		return replyDAO;
	}
	public void setReplyDAO(ReplyDAO replyDAO) {
		this.replyDAO = replyDAO;
	}
	public UserDAO getUserDAO() {
		return userDAO;
	}
	public void setUserDAO(UserDAO userDAO) {
		this.userDAO = userDAO;
	}

	public String getJsonString() {
		return jsonString;
	}
	public void setJsonString(String jsonString) {
		this.jsonString = jsonString;
	}
	
	/**
	 * 列出帖子详情里的主层评论
	 */
	public void listm(){
		CommonUtil.doSometing(new MyRunnable() {
			
			@Override
			public void run(OnResultListener listener) {
				System.out.println("listmReply@ReplyAction");
				Reply replyObject = (Reply) GsonUtil.jsonToObject(getJsonString(), Reply.class);
				int nid = replyObject.getNid();
				if(nid!=0){
					listener.onSuccess(replyDAO.listm(nid));	
				}else{
					listener.onFailure("暂无回复信息");
				}
			}
		});
	}
	
	
	/**
	 * 新增一条评论
	 */
	public void add(){
		CommonUtil.doSometing(new MyRunnable() {
			
			@Override
			public void run(OnResultListener listener) {
				System.out.println("addReply@ReplyAction");
				Reply replyObject = (Reply) GsonUtil.jsonToObject(getJsonString(), Reply.class);
				if(replyObject!=null){
					Serializable result = replyDAO.add(replyObject);
					if(result!=null){
						listener.onSuccess(null);
					}else{
						listener.onFailure("无法访问数据");
					}
				}else{
					listener.onFailure("请输入内容");
				}
			}
		});
	}
}
