package com.suramire.miaowu.action;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;
import com.suramire.miaowu.bean.Note;
import com.suramire.miaowu.bean.NotePhoto;
import com.suramire.miaowu.bean.User;
import com.suramire.miaowu.dao.NoteDAO;
import com.suramire.miaowu.util.CommonUtil;
import com.suramire.miaowu.util.GsonUtil;
import com.suramire.miaowu.util.MyRunnable;
import com.suramire.miaowu.util.OnResultListener;

/**
*
* @author Suramire
* 
* 帖子相关操作
*
*/

public class NoteAction {
	NoteDAO noteDAO;
	String jsonString;
	// 从客户端传来的图片
	File picture;
	// 图片名
	String pictureFileName;
	
	/**
	 * 审核通过
	 */
	public void pass(){
		CommonUtil.doSometing(new MyRunnable() {
			@Override
			public void run(OnResultListener listener) {
				System.out.println("pass@NoteAction");
				Note note = (Note) GsonUtil.jsonToObject(getJsonString(),Note.class);
				if(note!=null){
					noteDAO.pass(note.getId());
					listener.onSuccess(null);
				}else{
					listener.onFailure("未接收到操作的帖子编号");
				}
				
			}
		});
	}
	
	/**
	 * 审核不通过
	 */
	public void unPass(){
		CommonUtil.doSometing(new MyRunnable() {
			@Override
			public void run(OnResultListener listener) {
				System.out.println("unpass@NoteAction");
				Note note = (Note) GsonUtil.jsonToObject(getJsonString(),Note.class);
				if(note!=null){
					noteDAO.unpass(note);
					listener.onSuccess(null);
				}else{
					listener.onFailure("未接收到驳回理由");
				}
				
			}
		});
	}
	
	
	/**
	 * 锁定帖子
	 */
	public void lock(){
		CommonUtil.doSometing(new MyRunnable() {
			@Override
			public void run(OnResultListener listener) {
				System.out.println("lock@NoteAction");
				Note note = (Note) GsonUtil.jsonToObject(getJsonString(),Note.class);
				if(note!=null){
					noteDAO.lock(note.getId());
					listener.onSuccess(null);
				}else{
					listener.onFailure("未接收到需锁定的帖子的编号");
				}
				
			}
		});
	}
		
	/**
	 * 解锁帖子
	 */
	public void unlock(){
		CommonUtil.doSometing(new MyRunnable() {
			@Override
			public void run(OnResultListener listener) {
				System.out.println("lock@NoteAction");
				Note note = (Note) GsonUtil.jsonToObject(getJsonString(),Note.class);
				if(note!=null){
					noteDAO.unlock(note.getId());
					listener.onSuccess(null);
				}else{
					listener.onFailure("未接收到需锁定的帖子的编号");
				}
				
			}
		});
	}
	
	/**
	 * 删除帖子
	 */
	public void delete(){
		CommonUtil.doSometing(new MyRunnable() {
			@Override
			public void run(OnResultListener listener) {
				System.out.println("delete@NoteAction");
				Note note = (Note) GsonUtil.jsonToObject(getJsonString(),Note.class);
				if(note!=null){
					noteDAO.delete(note.getId());
					listener.onSuccess(null);
				}else{
					listener.onFailure("未接收到需删除的帖子编号");
				}
				
			}
		});
	}
	
	/**
	 * 修改帖子信息
	 */
	public void update(){
		CommonUtil.doSometing(new MyRunnable() {
			@Override
			public void run(OnResultListener listener) {
				System.out.println("update@NoteAction");
				Note note = (Note) GsonUtil.jsonToObject(getJsonString(),Note.class);
				if(note!=null){
					noteDAO.update(note);
					listener.onSuccess(null);
				}else{
					listener.onFailure("未接收到需修改的帖子编号");
				}
				
			}
		});
	}
	
	
	/**
	 * 列出未审核的帖子
	 */
	public void listunverify() {
		CommonUtil.doSometing(new MyRunnable() {

			@Override
			public void run(OnResultListener listener) {
				System.out.println("listunverify@NoteAction");
				List<Note> listunverify = noteDAO.listunverify();
				System.out.println(listunverify.size());
				listener.onSuccess(noteDAO.listunverify());
			}
		});
	}

	/**
	 * 点赞操作
	 */
	public void thumb() {
		CommonUtil.doSometing(new MyRunnable() {
			@Override
			public void run(OnResultListener listener) {
				System.out.println("thumb@NoteAction");
				Note note = (Note) GsonUtil.jsonToObject(getJsonString(),Note.class);
				noteDAO.thumb(note.getId());
				listener.onSuccess(null);
			}
		});
	}

	/**
	 * 获取帖子详情
	 */
	public void getDetail() {
		CommonUtil.doSometing(new MyRunnable() {

			@Override
			public void run(OnResultListener listener) {
				System.out.println("getDetail@NoteAction");
				Note note = (Note) GsonUtil.jsonToObject(getJsonString(),
						Note.class);
				Note tNote = noteDAO.get(note.getId());
				if (tNote != null) {
					listener.onSuccess(tNote);
				} else {
					listener.onFailure("所查看的帖子不存在");
				}

			}
		});
	}

	/**
	 * 获取帖子所有的配图
	 */
	public void getAllPicture() {
		System.out.println("getAllPicture@NoteAction");
		CommonUtil.doSometing(new MyRunnable() {

			@Override
			public void run(OnResultListener listener) {
				Note note = (Note) GsonUtil.jsonToObject(getJsonString(),
						Note.class);
				List<String> pictueList = noteDAO.getAllPictureById(note
						.getId());
				if (pictueList != null) {
					listener.onSuccess(pictueList);
				} else {
					listener.onFailure("未找到该帖子的配图");
				}
			}
		});
	}



	/**
	 * 保存图片至服务器目录
	 */

	public void getPic() {
		System.out.println("getPic@NoteAction");
		CommonUtil.doSometing(new MyRunnable() {

			public void run(OnResultListener listener) {
				if (picture != null) {
					String filePath = ServletActionContext.getServletContext()
							.getRealPath("/upload/note/");// 获取服务器上的图片存放路径
					try {
						FileUtils.copyFile(picture, new File(filePath,
								pictureFileName));
						listener.onSuccess(null);
					} catch (IOException e) {
						listener.onError("服务器保存图片时出现错误");
					}
				} else {
					listener.onFailure("服务器未接收到图片");
				}
			}
		});
	}

	/**
	 * 保存帖子配图路径
	 */
	public void picToDB() {
		System.out.println("picToDB@NoteAction");
		CommonUtil.doSometing(new MyRunnable() {
			@SuppressWarnings("unchecked")
			@Override
			public void run(OnResultListener listener) {
				boolean ok = true;
				System.out.println(getJsonString());
				List<HashMap> nameList = GsonUtil.jsonToList(getJsonString(),
						HashMap.class);
				for (HashMap<String, String> map : nameList) {
					NotePhoto notePhoto = new NotePhoto(Integer.parseInt(map
							.get("nid")), map.get("picname"));
					if (noteDAO.add(notePhoto) == null) {
						ok = false;
					}
				}
				if (!ok) {
					listener.onFailure("图片映射失败");
				} else {
					listener.onSuccess(null);
				}
			}
		});
	}

	/**
	 * 获取用户发帖数
	 */
	public void getuCount() {
		CommonUtil.doSometing(new MyRunnable() {
			public void run(OnResultListener listener) {
				User user = (User) GsonUtil.jsonToObject(getJsonString(),
						User.class);
				if (user != null) {
					int count = noteDAO.getNoteCount(user.getId());
					listener.onSuccess(count);
				} else {
					listener.onFailure("未接收到用户编号");
				}
			}
		});
	}

	/**
	 * 根据用户id获取帖子信息
	 */
	public void getByUser() {
		System.out.println("getNoteByUser@UserAction");
		CommonUtil.doSometing(new MyRunnable() {
			public void run(OnResultListener listener) {
				User user = (User) GsonUtil.jsonToObject(getJsonString(),
						User.class);
				if (user != null) {
					List<Note> notes = noteDAO.getNoteByUser(user.getId());
					listener.onSuccess(notes);
				} else {
					listener.onFailure("未接收到用户编号");
				}
			}
		});
	}
	
	public void getByUserAll() {
		System.out.println("getNoteByUserAll@UserAction");
		CommonUtil.doSometing(new MyRunnable() {
			public void run(OnResultListener listener) {
				User user = (User) GsonUtil.jsonToObject(getJsonString(),
						User.class);
				if (user != null) {
					List<Note> notes = noteDAO.getNoteByUserAll(user.getId());
					listener.onSuccess(notes);
				} else {
					listener.onFailure("未接收到用户编号");
				}
			}
		});
	}
	
	/**
	 * 发布新帖子
	 */
	public void add() {
		CommonUtil.doSometing(new MyRunnable() {
			@Override
			public void run(OnResultListener listener) {
				System.out.println("add@NoteAction");
				//获取安卓端传送来的json字符串并将其解析成Note对象
				Note note = (Note) GsonUtil.jsonToObject(getJsonString(),
						Note.class);
				if(note!=null){
					//Note对象不为空时保存
					Serializable add = noteDAO.add(note);
					String idString = GsonUtil.objectToJson(add);
					if (add != null) {
						//成功添加Note对象至数据库后 将新帖子的编号返回给安卓端
						listener.onSuccess(Integer.parseInt(idString));
					}
				}
				 else {
					listener.onFailure("未收到帖子信息");
				}
			}
		});
	}

	/**
	 * 列出首页推荐帖子
	 */
	public void listm() {
		System.out.println("listm@NoteAction");
		CommonUtil.doSometing(new MyRunnable() {

			@Override
			public void run(OnResultListener listener) {
				listener.onSuccess(noteDAO.getMultiNotes());
			}
		});
	}
	
	
	/**
	 * 帖子模糊搜索
	 */
	public void search(){
		System.out.println("search@NoteAction");
		CommonUtil.doSometing(new MyRunnable() {

			@Override
			public void run(OnResultListener listener) {
				Note note = (Note) GsonUtil.jsonToObject(getJsonString(),
						Note.class);
				String content = note.getContent();
				if(content!=null &&!content.equals("")){
					List<Note> searchResult = noteDAO.getSearchResult(content);
					listener.onSuccess(searchResult);
				}else{
					listener.onFailure("未接收到搜索关键字");
				}
			}
		});
	}
	
	/**
	 * 使浏览数增加一
	 */
	public void increasecount(){
		System.out.println("increasecount@NoteAction");
		CommonUtil.doSometing(new MyRunnable() {
			@Override
			public void run(OnResultListener listener) {
				Note note = (Note) GsonUtil.jsonToObject(getJsonString(),
						Note.class);
				if(note !=null){
					noteDAO.increasecount(note.getId());
				}else{
					listener.onFailure("未接收到帖子编号");
				}
			}
		});
	}

	public NoteDAO getNoteDAO() {
		return noteDAO;
	}

	public void setNoteDAO(NoteDAO noteDAO) {
		this.noteDAO = noteDAO;
	}

	public String getJsonString() {
		return jsonString;
	}

	public void setJsonString(String jsonString) {
		this.jsonString = jsonString;
	}

	public File getPicture() {
		return picture;
	}

	public void setPicture(File picture) {
		this.picture = picture;
	}

	public String getPictureFileName() {
		return pictureFileName;
	}

	public void setPictureFileName(String pictureFileName) {
		this.pictureFileName = pictureFileName;
	}

}
