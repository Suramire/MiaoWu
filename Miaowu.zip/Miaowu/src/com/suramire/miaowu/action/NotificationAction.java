package com.suramire.miaowu.action;


import com.suramire.miaowu.bean.Notification;
import com.suramire.miaowu.bean.User;
import com.suramire.miaowu.dao.NotificationDAO;
import com.suramire.miaowu.util.CommonUtil;
import com.suramire.miaowu.util.GsonUtil;
import com.suramire.miaowu.util.MyRunnable;
import com.suramire.miaowu.util.OnResultListener;

/**
*
* @author Suramire
* 
* 通知相关操作
*
*/
public class NotificationAction{
	String jsonString;
	NotificationDAO nofiticationDAO;
	
	
	/**
	 * 列出所有通知
	 */
	public void listunread(){
		System.out.println("listunread@NotificationAction");
		CommonUtil.doSometing(new MyRunnable() {
			public void run(OnResultListener listener) {
				User user =  (User) GsonUtil.jsonToObject(getJsonString(), User.class);
				if(user!=null){
					listener.onSuccess(nofiticationDAO.listAll(user.getId()));
				}else{
					listener.onFailure("未接收到用户编号");
				}
				
			}
		});
	}
	/**
	 * 阅读一条通知
	 */
	public void read(){
		System.out.println("read@NotificationAction");
		CommonUtil.doSometing(new MyRunnable() {
			public void run(OnResultListener listener) {
				Notification notification =  (Notification) GsonUtil.jsonToObject(getJsonString(), Notification.class);
				if(notification!=null){
					listener.onSuccess(nofiticationDAO.readNotification(notification));
				}else{
					listener.onFailure("未接收到通知编号");
				}
				
			}
		});
	}
	/**
	 * 获取已登录用户的未读通知数
	 */
	public void getunreadCount(){
		System.out.println("getunreadCount@NotificationAction");
		CommonUtil.doSometing(new MyRunnable() {
			public void run(OnResultListener listener) {
				User user =  (User) GsonUtil.jsonToObject(getJsonString(), User.class);
				if(user!=null){
					listener.onSuccess(nofiticationDAO.getunreadCount(user.getId()));
				}else{
					listener.onFailure("未接收到用户编号");
				}
				
			}
		});
	}
	
	public String getJsonString() {
		return jsonString;
	}
	public void setJsonString(String jsonString) {
		this.jsonString = jsonString;
	}
	public NotificationDAO getNofiticationDAO() {
		return nofiticationDAO;
	}
	public void setNofiticationDAO(NotificationDAO nofiticationDAO) {
		this.nofiticationDAO = nofiticationDAO;
	}
}
