package com.suramire.miaowu.action;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;

import com.suramire.miaowu.bean.CatPhoto;
import com.suramire.miaowu.bean.Catinfo;
import com.suramire.miaowu.dao.CatDAO;
import com.suramire.miaowu.util.CommonUtil;
import com.suramire.miaowu.util.GsonUtil;
import com.suramire.miaowu.util.MyRunnable;
import com.suramire.miaowu.util.OnResultListener;

/**
*
* @author Suramire
* 
* 猫咪相关操作
*
*/

public class CatAction {
	
    String jsonString;
    CatDAO catDAO;
	// 从客户端传来的图片
	File picture;
	// 图片名
	String pictureFileName;
	
    
    /**
     * 添加一只猫
     */
	public void add(){
		System.out.println("add@CatAction");
		CommonUtil.doSometing(new MyRunnable() {
			@Override
			public void run(OnResultListener listener) {
				Catinfo catinfo = (Catinfo) GsonUtil.jsonToObject(getJsonString(),Catinfo.class);
				if(catinfo!=null){
					listener.onSuccess(catDAO.save(catinfo));
				}else{
					listener.onFailure("未接收到新猫咪信息");
				}
				
			}
		});
	}
	
	/**
	 * 获取一只猫的信息
	 */
	public void getOne(){
		System.out.println("getOne@CatAction");
		CommonUtil.doSometing(new MyRunnable() {
			@Override
			public void run(OnResultListener listener) {
				System.out.println("getJsonString():"+getJsonString());
				Catinfo catinfo = (Catinfo) GsonUtil.jsonToObject(getJsonString(),Catinfo.class);
				if(catinfo!=null){
					listener.onSuccess(catDAO.get(Catinfo.class, catinfo.getId()));
				}else{
					listener.onFailure("未接收到猫咪编号");
				}
			}
		});
	}
	
	
	/**
	 * 根据条件获取猫的列表
	 */
	public void getAll(){
		System.out.println("getAll@CatAction");
		CommonUtil.doSometing(new MyRunnable() {
			@Override
			public void run(OnResultListener listener) {
					Catinfo catinfo = (Catinfo) GsonUtil.jsonToObject(getJsonString(),Catinfo.class);
					if(catinfo!=null){
						Integer isAdopted = catinfo.getIsAdopted();
						if(isAdopted!=null){
							listener.onSuccess(catDAO.list(isAdopted));
						}else{
							
						}
					}else{
						listener.onSuccess(catDAO.list());
					}
				}
		});
	}
	
	/**
	 * 保存图片到服务器
	 */
	public void uploadPic() {
		System.out.println("uploadPic@CatAction");
		CommonUtil.doSometing(new MyRunnable() {

			public void run(OnResultListener listener) {
				if (picture != null) {
					String filePath = ServletActionContext.getServletContext()
							.getRealPath("/upload/cat/");// 获取服务器上的图片存放路径
					try {
						FileUtils.copyFile(picture, new File(filePath,
								pictureFileName));
						listener.onSuccess(null);
					} catch (IOException e) {
						listener.onError("服务器保存图片时出现错误");
					}
				} else {
					listener.onFailure("服务器未接收到图片");
				}
			}
		});
	}
	
	/**
	 * 保存猫咪配图路径到数据库
	 */
	public void picToDB() {
		System.out.println("picToDB@CatAction");
		CommonUtil.doSometing(new MyRunnable() {
			@SuppressWarnings("unchecked")
			@Override
			public void run(OnResultListener listener) {
				boolean ok = true;
				System.out.println(getJsonString());
				List<HashMap> nameList = GsonUtil.jsonToList(getJsonString(),
						HashMap.class);
				for (HashMap<String, String> map : nameList) {
					CatPhoto catPhoto = new CatPhoto(Integer.parseInt(map
							.get("cid")), map.get("picname"));
					if (catDAO.save(catPhoto) == null) {
						ok = false;
					}
				}
				if (!ok) {
					listener.onFailure("图片路径保存失败");
				} else {
					listener.onSuccess(null);
				}
			}
		});
	}
	
	
	/**
	 * 获取所有猫咪信息
	 */
	public void getpic(){
		System.out.println("getPictures@CatAction");
		CommonUtil.doSometing(new MyRunnable() {

			public void run(OnResultListener listener) {
				Catinfo catinfo = (Catinfo) GsonUtil.jsonToObject(getJsonString(),Catinfo.class);
				if(catinfo!=null){
					listener.onSuccess(catDAO.getAllPictureById(catinfo.getId()));
				}else{
					listener.onFailure("未接收到猫咪信息");
				}
			}
		});
	}
	
	/**
	 * 列出已被领养的猫
	 */
	public void getAdopted(){
		System.out.println("getAdopted@CatAction");
		CommonUtil.doSometing(new MyRunnable() {

			public void run(OnResultListener listener) {
				Catinfo catinfo = (Catinfo) GsonUtil.jsonToObject(getJsonString(),Catinfo.class);
				if(catinfo!=null){
					listener.onSuccess(catDAO.getAdoptedCat(catinfo.getUid()));
				}else{
					listener.onFailure("未接收到用户编号信息");
				}
			}
		});
	}
	
	/**
	 * 审核领养申请
	 */
	public void reviewApply(){
		System.out.println("reviewApply@CatAction");
		CommonUtil.doSometing(new MyRunnable() {

			public void run(OnResultListener listener) {
				Catinfo catinfo = (Catinfo) GsonUtil.jsonToObject(getJsonString(),Catinfo.class);
				if(catinfo!=null){
					if(catDAO.reviewApplyCat(catinfo.getId(), catinfo.getIsAdopted())){
						listener.onSuccess(null);
					}
					
				}else{
					listener.onFailure("未接收到用户编号信息");
				}
			}
		});
	}
	
	/**
	 * 申请领养
	 */
	public void apply(){
		System.out.println("apply@CatAction");
		CommonUtil.doSometing(new MyRunnable() {

			public void run(OnResultListener listener) {
				Catinfo catinfo = (Catinfo) GsonUtil.jsonToObject(getJsonString(),Catinfo.class);
				if(catinfo!=null){
					if(catDAO.applyCat(catinfo.getId(), catinfo.getUid())){
						listener.onSuccess(null);
					}else{
						listener.onFailure("该猫已被其他用户申请，请选择其他进行领养");
					}
				}else{
					listener.onFailure("未接收到用户编号信息");
				}
			}
		});
	}
	
	/**
	 * 列出所有待审核的领养申请
	 */
	public void listapp(){
		System.out.println("listapp@CatAction");
		CommonUtil.doSometing(new MyRunnable() {

			public void run(OnResultListener listener) {
				listener.onSuccess(catDAO.listppliedCat());
			}
		});
	}
	
	public String getJsonString() {
		return jsonString;
	}

	public void setJsonString(String jsonString) {
		this.jsonString = jsonString;
	}

	public CatDAO getCatDAO() {
		return catDAO;
	}

	public void setCatDAO(CatDAO catDAO) {
		this.catDAO = catDAO;
	}
	
	public File getPicture() {
		return picture;
	}

	public void setPicture(File picture) {
		this.picture = picture;
	}

	public String getPictureFileName() {
		return pictureFileName;
	}

	public void setPictureFileName(String pictureFileName) {
		this.pictureFileName = pictureFileName;
	}
	
}
