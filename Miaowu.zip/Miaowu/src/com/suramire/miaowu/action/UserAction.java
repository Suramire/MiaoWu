package com.suramire.miaowu.action;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;

import com.suramire.miaowu.bean.Follow;
import com.suramire.miaowu.bean.User;
import com.suramire.miaowu.dao.UserDAO;
import com.suramire.miaowu.util.CommonUtil;
import com.suramire.miaowu.util.GsonUtil;
import com.suramire.miaowu.util.MyRunnable;
import com.suramire.miaowu.util.OnResultListener;

/**
 * 
 * @author Suramire
 * 
 *         用户相关操作
 * 
 */

public class UserAction {

	UserDAO userDAO;
	// 从客户端传来的图片
	File picture;
	// 图片名
	String pictureFileName;
	String jsonString;

	/**
	 * 修改用户信息
	 */
	public void update() {
		CommonUtil.doSometing(new MyRunnable() {
			// 用户名不能是纯数字 防止使用其他用户的手机号作为用户名
			public void run(OnResultListener listener) {
				User user = (User) GsonUtil.jsonToObject(getJsonString(),
						User.class);
				if (user != null) {
					System.out.println("getJsonString():"+getJsonString());
					userDAO.update(user);
					listener.onSuccess(userDAO.getUser(user.getId()));
				} else {
					listener.onError("未接收到用户信息");
				}

			}
		});
	}


	/**
	 * 用户注册 输入 user对象 用户名 手机号 密码
	 */
	public void add() {
		System.out.println("add@UserAction");
		CommonUtil.doSometing(new MyRunnable() {
			// 用户名不能是纯数字 防止使用其他用户的手机号作为用户名
			public void run(OnResultListener listener) {
				User user = (User) GsonUtil.jsonToObject(getJsonString(),
						User.class);
				if (user != null) {
					if (user.getPhonenumber().equals(user.getNickname()) || userDAO.findPhone(user.getNickname()) != null) {
						listener.onFailure("请勿使用手机号码作为用户名");
					}else{
						user.setBirthday(new Date());
						if (userDAO.add(user) != null) {
							listener.onSuccess(null);
						}
					}
				} else {
					listener.onError("未接收到用户注册信息");
				}

			}
		});
	}

	/**
	 * 用户登录 输入：用户名、密码
	 */
	public void login() {
		CommonUtil.doSometing(new MyRunnable() {
			public void run(OnResultListener listener) {
				User user = (User) GsonUtil.jsonToObject(getJsonString(),
						User.class);
				if (user != null) {
					User tUser = userDAO.login(user.getNickname(), user
							.getPassword());
					if (tUser != null) {
						// 登录成功
						listener.onSuccess(tUser);
					} else {
						listener.onFailure("用户名或密码错误");
					}
				} else {
					listener.onFailure("未接收到帐户信息");
				}
			}
		});
	}

	/**
	 * 手机号已注册判断 输入：手机号
	 */
	public void checkPhone() {
		System.out.println("checkPhone@UserAction");
		CommonUtil.doSometing(new MyRunnable() {
			public void run(OnResultListener listener) {
				User user = (User) GsonUtil.jsonToObject(getJsonString(),
						User.class);
				if (userDAO.findPhone(user.getPhonenumber()) != null) {
					listener.onFailure("该号码已被注册，请尝试使用其他号码注册");
				} else {
					listener.onSuccess(null);
				}
			}
		});
	}

	/**
	 * 根据uid获取一个用户的信息
	 */
	public void get() {
		CommonUtil.doSometing(new MyRunnable() {
			public void run(OnResultListener listener) {
				System.out.println("get@UserAction");
				User user = (User) GsonUtil.jsonToObject(getJsonString(),
						User.class);
				if (user != null) {
					User user2 = userDAO.getUser(user.getId());
					if (user2 != null) {
						listener.onSuccess(user2);
					} else {
						listener.onFailure("该编号对应的用户不存在");
					}
				} else {
					listener.onFailure("未接收到用户编号");
				}
			}
		});
	}

	/**
	 * 获取用户关注数
	 */
	public void getFollowCount() {
		CommonUtil.doSometing(new MyRunnable() {
			public void run(OnResultListener listener) {
				User user = (User) GsonUtil.jsonToObject(getJsonString(),
						User.class);
				if (user != null) {
					int count = userDAO.getUserFollowCount(user.getId());
					listener.onSuccess(count);
				} else {
					listener.onFailure("未接收到用户编号");
				}
			}
		});
	}

	/**
	 * 获取关注用户的信息
	 */
	public void getFollow() {
		CommonUtil.doSometing(new MyRunnable() {
			public void run(OnResultListener listener) {
				System.out.println("getFollow@UserAction");
				User user = (User) GsonUtil.jsonToObject(getJsonString(),
						User.class);
				if (user != null) {
					listener.onSuccess(userDAO.getUserFollow(user.getId()));
				} else {
					listener.onFailure("未接收到用户编号");
				}
			}
		});
	}

	/**
	 * 获取用户粉丝数
	 */
	public void getFollowerCount() {
		CommonUtil.doSometing(new MyRunnable() {
			public void run(OnResultListener listener) {
				User user = (User) GsonUtil.jsonToObject(getJsonString(),
						User.class);
				if (user != null) {
					int count = userDAO.getUserFollowerCount(user.getId());
					listener.onSuccess(count);
				} else {
					listener.onFailure("未接收到用户编号");
				}
			}
		});
	}

	/**
	 * 获取粉丝的信息
	 */
	public void getFollower() {
		CommonUtil.doSometing(new MyRunnable() {
			public void run(OnResultListener listener) {
				System.out.println("getFollower@UserAction");
				User user = (User) GsonUtil.jsonToObject(getJsonString(),
						User.class);
				System.out.println("json:"+getJsonString());
				if (user != null) {
					listener.onSuccess(userDAO.getUserFollower(user.getId()));
				} else {
					listener.onFailure("未接收到用户编号");
				}
			}
		});
	}

	/**
	 * 关注用户
	 */
	public void follow() {
		System.out.println("followUser@UserAction");
		CommonUtil.doSometing(new MyRunnable() {
			public void run(OnResultListener listener) {
				Follow follow = (Follow) GsonUtil.jsonToObject(getJsonString(),
						Follow.class);
				if (follow != null) {
					listener.onSuccess(userDAO.follow(follow));
				} else {
					listener.onFailure("未接收到用户编号");
				}
			}
		});
	}

	/**
	 * 取消关注用户
	 */
	public void unfollow() {
		System.out.println("unfollowUser@UserAction");
		CommonUtil.doSometing(new MyRunnable() {
			public void run(OnResultListener listener) {
				Follow follow = (Follow) GsonUtil.jsonToObject(getJsonString(),
						Follow.class);
				if (follow != null) {
					listener.onSuccess(userDAO.unfollow(follow));
				} else {
					listener.onFailure("未接收到用户编号");
				}
			}
		});
	}

	/**
	 * 获取与用户的关系
	 */
	public void relationship() {
		System.out.println("relationship@UserAction");
		CommonUtil.doSometing(new MyRunnable() {
			public void run(OnResultListener listener) {
				Follow follow = (Follow) GsonUtil.jsonToObject(getJsonString(),
						Follow.class);
				if (follow != null) {
					listener.onSuccess(userDAO.getRelationship(follow));
				} else {
					listener.onFailure("未接收到用户编号");
				}
			}
		});
	}

	/**
	 * 搜索用户信息
	 */
	public void search() {
		System.out.println("search@UserAction");
		CommonUtil.doSometing(new MyRunnable() {
			public void run(OnResultListener listener) {
				User user = (User) GsonUtil.jsonToObject(getJsonString(),
						User.class);
				if (user != null) {
					List<User> search = userDAO.search(user.getNickname());
					System.out.println(search.size());
					listener.onSuccess(userDAO.search(user.getNickname()));
				} else {
					listener.onFailure("未接收到用户编号");
				}
			}
		});
	}

	/**
	 * 修改密码
	 */
	public void modifypwd() {
		System.out.println("modifypwd@UserAction");
		CommonUtil.doSometing(new MyRunnable() {
			public void run(OnResultListener listener) {
				User user = (User) GsonUtil.jsonToObject(getJsonString(),
						User.class);

				if (user != null) {
					if (userDAO.modifyPassword(user.getPhonenumber(), user
							.getPassword())) {
						listener.onSuccess(null);
					} else {
						listener.onFailure("请检查手机号是否是注册手机");
					}
				} else {
					listener.onFailure("未接收到用户编号");
				}
			}
		});
	}

	/**
	 * 保存图片至服务器目录
	 */

	public void uploadPic() {
		System.out.println("uploadPic@UserAction");
		CommonUtil.doSometing(new MyRunnable() {

			public void run(OnResultListener listener) {
				if (picture != null) {
					String filePath = ServletActionContext.getServletContext()
							.getRealPath("/upload/user/");// 获取服务器上的图片存放路径
					try {
						FileUtils.copyFile(picture, new File(filePath,
								pictureFileName));
						listener.onSuccess(null);
					} catch (IOException e) {
						listener.onError("服务器保存图片时出现错误");
					}
				} else {
					listener.onFailure("服务器未接收到图片");
				}
			}
		});
	}

	/**
	 * 更新用户头像字段
	 */

	public void updateAvater() {
		System.out.println("updateAvater@UserAction");
		CommonUtil.doSometing(new MyRunnable() {

			public void run(OnResultListener listener) {
				User user = (User) GsonUtil.jsonToObject(getJsonString(),
						User.class);
				if (user != null) {
					userDAO.updateAvater(user.getId());
					listener.onSuccess(null);
				} else {
					listener.onFailure("未收到用户编号");
				}
			}
		});
	}

	public String getJsonString() {
		return jsonString;
	}

	public void setJsonString(String jsonString) {
		this.jsonString = jsonString;
	}

	public File getPicture() {
		return picture;
	}

	public void setPicture(File picture) {
		this.picture = picture;
	}

	public String getPictureFileName() {
		return pictureFileName;
	}

	public void setPictureFileName(String pictureFileName) {
		this.pictureFileName = pictureFileName;
	}

	public File getFile() {
		return picture;
	}

	public void setFile(File file) {
		this.picture = file;
	}

	public UserDAO getUserDAO() {
		return userDAO;
	}

	public void setUserDAO(UserDAO userDAO) {
		this.userDAO = userDAO;
	}

}
