package com.suramire.miaowu.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.springframework.orm.hibernate3.HibernateTemplate;
import com.suramire.miaowu.bean.Follow;
import com.suramire.miaowu.bean.Notification;
import com.suramire.miaowu.bean.User;
import com.suramire.miaowu.util.CommonUtil;

public class UserDAO  extends HibernateTemplate {
	/**
	 * 列出所有用户信息
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<User> list() {
		return find("from User");
	}
	
	/**
	 * 添加一个用户
	 * @param user
	 * @return
	 */
	public Serializable add(User user){
		return save(user);
	}
	
	/**
	 * 修改用户密码
	 * @param uid
	 * @param newPassword
	 * @return
	 */
	public boolean modifyPassword(int uid,String newPassword){
		boolean flag = false;
		try{
			User user = super.get(User.class, uid);
			user.setPassword(newPassword);
			super.update(user);
			flag = true;
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	@SuppressWarnings("unchecked")
	public boolean modifyPassword(String phoneNumber,String newPassword){
		boolean flag = false;
		try{
			List<User> list = find("from User u where u.phonenumber=?",new Object[]{phoneNumber});
			if(list!=null && list.size()>0){
				User user = list.get(0);
				user.setPassword(newPassword);
				super.update(user);
				flag = true;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	/**
	 * 更新用户头像路径
	 */
	public void updateAvater(int uid){
		User user = super.get(User.class, uid);
		user.setIcon(uid+".png");//直接以用户编号作为头像的文件名
		super.update(user);
	}
	
	/**
	 * 查询符合条件的用户信息
	 * 用作登录验证
	 * @param username 用户名
	 * @param password 密码
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public User login(String username,String password){
		List<User> lists = new ArrayList<User>();
		//根据用户名栏目格式判断是用户名还是手机号
		if(CommonUtil.isMobileNumber(username)){
			lists = find("from User u where u.phonenumber = ? and u.password = ? ",new Object[]{username,password});
		}else{
			lists = find("from User u where u.nickname = ? and u.password = ? ",new Object[]{username,password});
		}
		if(lists.size()>0){
			return lists.get(0);
		}
		return null;
	}
	/**
	 * 查询符合条件的用户信息
	 * 用作检查手机号是否已被注册
	 * @param phoneNumber 手机号
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public User findPhone(String phoneNumber){
		List<User> lists = new ArrayList<User>();
		lists = find("from User u where u.phonenumber = ?",new Object[]{phoneNumber});
		if(lists.size()>0){
			return lists.get(0);
		}
		return null;
	}
	/**
	 * 根据id查找对应用户信息
	 * @param uid
	 * @return
	 */
	public User getUser(int uid){
		return get(User.class,uid);
	}
	/**
	 * 根据id list 返回对应 user list
	 * @param ids
	 * @return
	 */
	public List<User> getUsersById(List<Integer> ids){
		List<User> users = new ArrayList<User>();
		for (Integer i : ids) {
			users.add(getUser(i));
		}
		return users;
	}
	
	
	/**
	 * 获取用户关注数
	 * @param uid 
	 * @return
	 */
	public int getUserFollowCount(int uid){
		return find("from Follow f where f.uid1 = ?",new Object[]{uid}).size();
	}
	
	/**
	 * 获取用户关注的用户信息
	 * @param uid
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<User> getUserFollow(int uid){
		List<User> users = new ArrayList<User>();
		 List<Follow> follows = find("from Follow f where f.uid1 = ?",new Object[]{uid});
		 if(follows!=null && follows.size()>0){
			 for(int i=0;i<follows.size();i++){
				 users.add(super.get(User.class, follows.get(i).getUid2()));
			 }
		 }
		 return users;
	}
	
	
	/**
	 * 获取用户粉丝数
	 * @param uid
	 * @return
	 */
	public int getUserFollowerCount(int uid){
		return find("from Follow f where f.uid2 = ?",new Object[]{uid}).size();
	}
	
	/**
	 * 获取用户粉丝的信息
	 * @param uid
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<User> getUserFollower(int uid){
		List<User> users = new ArrayList<User>();
		 List<Follow> follows = find("from Follow f where f.uid2 = ?",new Object[]{uid});
		 if(follows!=null && follows.size()>0){
			 for(int i=0;i<follows.size();i++){
				 users.add(super.get(User.class, follows.get(i).getUid1()));
			 }
		 }
	
		 return users;
	}
	
	/**
	 * 关注用户
	 * 同时生成关注通知
	 * @param follow
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public boolean follow(Follow follow){
		int uid1 = follow.getUid1();
		int uid2 = follow.getUid2();
		Serializable save = super.save(follow);
		//生成通知
		//先查询是否已生成过
		List<Notification> find = find("from Notification n where n.uid1=? and n.uid2=? and n.type=1",new Object[]{uid1,uid2});
		if(find!=null && find.size()>0){
			//已生成过关注通知
		}else{
			//未生成过通知
			User user = super.get(User.class, uid1);
			Notification notification = new Notification();
			notification.setUid1(uid1);
			notification.setUid2(uid2);
			notification.setContent(user.getNickname()+" 关注了你.");
			notification.setTime(CommonUtil.getTimeStamp());
			notification.setType(1);
			notification.setIsread(0);
			super.save(notification);
		}
		
		return save!=null;
	}
	
	/**
	 * 取消关注
	 * @param follow
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public boolean unfollow(Follow follow){
		List<Follow> find = find("from Follow f where f.uid1 = ? and f.uid2 = ?",new Object[]{follow.getUid1(),follow.getUid2()});
		if(find!=null && find.size()>0){
			Follow follow2 = super.get(Follow.class, find.get(0).getId());
			super.delete(follow2);
			return true;
		}
		return false;
	}
	
	/**
	 * 获取两个用户间的关系
	 * @param follow
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public int getRelationship(Follow follow){
		int uid1 = follow.getUid1();
		int uid2 = follow.getUid2();
		if(uid1==0||uid2==0){
			//未登录用户 或查看的用户不存在
			return 0;
		}
		List<Follow> find = find("from Follow f where f.uid1=? and f.uid2=?",new Object[]{uid1,uid2});
		List<Follow> find2 = find("from Follow f where f.uid2=? and f.uid1=?",new Object[]{uid1,uid2});
		if(find!=null && find.size()>0){
			//用户关注了页面用户
			if(find2!=null && find2.size()>0){
				//互相关注
				return 3;
			}else{
				//登录的用户关注了页面上的用户
				return 1;
			}
		}else{
			return 2;
		}
	}
	
	/**
	 * 模糊搜索用户
	 * @param query 用户名关键字 或完整手机号
	 * @return 用户列表
	 */
	@SuppressWarnings("unchecked")
	public List<User> search(String query){
		return find("from User u where u.nickname like '%"+query+"%' or u.phonenumber='"+query+"'");
	}
}
