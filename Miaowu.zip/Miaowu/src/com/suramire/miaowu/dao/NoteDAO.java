package com.suramire.miaowu.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.suramire.miaowu.bean.M;
import com.suramire.miaowu.bean.Note;
import com.suramire.miaowu.bean.NotePhoto;
import com.suramire.miaowu.bean.Notification;
import com.suramire.miaowu.bean.User;
import com.suramire.miaowu.util.CommonUtil;
import com.suramire.miaowu.util.GsonUtil;


public class NoteDAO extends HibernateTemplate {
	
	/**
	 * 审核通过
	 * @param noteId
	 */
	public void pass(int noteId){
		//变更帖子审核状态
		Note note = super.get(Note.class, noteId);
		note.setVerified(1);
		super.update(note);
		Notification notification = new Notification();
		notification.setContent("你发布的帖子\""+note.getTitle()+"\"审核通过了.");
		notification.setTime(CommonUtil.getTimeStamp());
		notification.setUid1(noteId);//保存通过审核的帖子的编号
		notification.setUid2(note.getUid());
		notification.setIsread(0);
		notification.setType(2);
		super.save(notification);
		
	}
	
	/**
	 * 审核不通过
	 * @param note
	 */
	public void unpass (Note note){
		Note note2 = super.get(Note.class,note.getId());
		note2.setVerified(2);
		super.update(note2);
		Notification notification = new Notification();
		notification.setContent("你发布的帖子\""+note2.getTitle()+"\"审核未通过，驳回理由:"+note.getContent());
		notification.setTime(CommonUtil.getTimeStamp());
		notification.setUid1(-1);//代表系统通知
		notification.setUid2(note2.getUid());
		notification.setIsread(0);
		notification.setType(2);
		super.save(notification);
		
	}
	
	/**
	 * 显示帖子列表
	 * @return
	 */
	
	@SuppressWarnings("unchecked")
	public List<Note> listunverify(){
		return find("from Note n where n.verified=0");
	}
	/**
	 * 添加新帖子
	 * @param note
	 * @return
	 */
	public Serializable add(Note note){
		return super.save(note);
	}

	/**
	 * 锁定帖子
	 * @param noteId
	 */
	public void lock(int noteId){
		Note note = super.get(Note.class, noteId);
		note.setVerified(3);
		super.update(note);
	}
	
	/**
	 * 解锁帖子
	 * @param noteId
	 */
	public void unlock(int noteId){
		Note note = super.get(Note.class, noteId);
		note.setVerified(1);
		super.update(note);
	}
	
	/**
	 * 更新帖子信息
	 * @param note
	 */
	public void update(Note note){
		super.update(note);
	}
	
	/**
	 * 删除指定帖子
	 * @param note
	 */
	public void delete(Note note){
		super.delete(note);
	}
	
	public void delete(int noteId){
		super.delete(get(noteId));
	}
	
	/**
	 * 点赞/喜欢帖子
	 * @param noteId
	 */
	public void thumb(int noteId){
		Note note = get(noteId);
		note.setThumbs(note.getThumbs()+1);
		super.update(note);
	}
	
	/**
	 * 根据id获取单个帖子信息
	 * @param noteId
	 * @return
	 */
	public Note get(int noteId){
		return super.get(Note.class,noteId);
	}
	
	
	/**
	 * 保存帖子配图
	 * @param notePhoto
	 */
	public Serializable add(NotePhoto notePhoto){
		return super.save(notePhoto);
	}
	
	
	/**
	 * 首页帖子列表
	 * @return 已审核的帖子
	 */
	
	@SuppressWarnings("unchecked")
	public List<M> getMultiNotes(){
		List<M> list = new ArrayList<M>();
		List<Note> notes = find("from Note n where n.verified=1");
		if(notes != null){
			for(Note note : notes){
				list.add(getMultiBean(note.getId()));
			}
		}
		
		return list;
	}

	
	
	
	@SuppressWarnings("unchecked")
	public M getMultiBean(int noteId){
		M m = new M();
		List<Object[]> list =
		find("select u,n from User u,Note n where u.id=n.uid and n.id=? ",new Object[]{noteId});
		if(list!=null){
			 Object[] objects = list.get(0);
			 User user = (User) objects[0];
			 Note note = (Note) objects[1];
			 String noteJson = GsonUtil.objectToJson(note);
			 String userJson = GsonUtil.objectToJson(user);
			 m.setStringx(noteJson);//帖子数据
			 m.setStringy(userJson);//用户数据
			 m.setStringz(note.getId()+"_0.png");//第一张图片名
			 m.setIntx(find("from Reply r where r.nid = ?",new Object[]{note.getId()}).size());//帖子回复数
		}
		return m;
	}
	
	/**
	 * 获帖子的所有配图路径文件名
	 * @param noteId 目标帖子id
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<String> getAllPictureById(int noteId){
		List<String> list = new ArrayList<String>();
		List<NotePhoto> temp  =find("from NotePhoto np where np.nid=?",new Object[]{noteId});
		for (NotePhoto note : temp) {
			list.add(note.getName());
		}
		return list;
	}
	
	/**
	 * 获取用户发帖数
	 * @param uid
	 * @return
	 */
	public int getNoteCount(int uid){
		return getNoteByUser(uid).size();
	}
	
	@SuppressWarnings("unchecked")
	public List<Note> getNoteByUser(int uid){
		return  find("from Note n where n.uid= ? and n.verified=1",new Object[]{uid});
	}
	
	/**
	 * 列出审核通过以及锁定的帖子
	 * @param uid
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Note> getNoteByUserAll(int uid){
		return  find("from Note n where n.uid= ? and n.verified in (1,3)",new Object[]{uid});
	}
	

	/**
	 * 模糊查询帖子信息
	 * @param query 关键字
	 * @return 帖子列表
	 */
	@SuppressWarnings("unchecked")
	public List<Note> getSearchResult(String query){
		return  find("from Note n where n.title like '%"+query+"%' or n.content like '%"+query+"%'");
	}
	
	/**
	 * 使浏览数加一
	 * @param noteId 目标帖子编号
	 */
	public void increasecount(int noteId){
		Note note = get(noteId);
		note.setViewcount(note.getViewcount()+1);
		update(note);
	}
}
