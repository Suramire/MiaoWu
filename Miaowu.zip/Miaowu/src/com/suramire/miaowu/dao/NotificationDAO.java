package com.suramire.miaowu.dao;

import java.io.Serializable;
import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.suramire.miaowu.bean.Notification;

public class NotificationDAO  extends HibernateTemplate{
	
	/**
	 * 新增一条通知
	 * @param notification
	 * @return
	 */
	public Serializable newNotification(Notification notification) {
		return super.save(notification);
	}
	
	
	/**
	 * 阅读一条通知
	 * @param notification
	 */
	public int readNotification(Notification notification){
		int id = notification.getId();
		Notification notification2 = super.get(Notification.class, id);
		notification2.setIsread(1);
		super.update(notification2);
		return id;
	}
	
	
	/**
	 * 列出该用户的所有未读通知
	 * @param uid
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Notification> listAll(int uid){
		return find("from Notification n where n.uid2=? ORDER BY time desc",new Object[]{uid});
	}
	/**
	 * 获取未读通知数
	 */
	public int getunreadCount(int uid){
		return find("from Notification n where n.uid2=? and isread=0",new Object[]{uid}).size();
	}
	
	

}
