package com.suramire.miaowu.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.suramire.miaowu.bean.M;
import com.suramire.miaowu.bean.Reply;
import com.suramire.miaowu.bean.User;
import com.suramire.miaowu.util.GsonUtil;

public class ReplyDAO extends HibernateTemplate {
	
	
	
	@SuppressWarnings("unchecked")
	public List<Reply> list(int nid){
		return find("from Reply r where r.nid = ? and r.replyuid=0",new Object[]{nid});
	}
	
	/**
	 * 列出帖子详情页的主楼评论
	 * @param nid
	 * @return
	 */
	public List<M> listm(int nid){
		List<M> mList = new ArrayList<M>();
		List<Reply> replies = list(nid);
		if(replies!=null && replies.size()>0){
			for (int i = 0; i < replies.size(); i++) {
				M m = new M();
				Reply reply = replies.get(i);
				String replyJson = GsonUtil.objectToJson(reply);
				User user = super.get(User.class, replies.get(i).getUid());
				String userJson = GsonUtil.objectToJson(user);
				m.setStringx(replyJson);//评论本体
				m.setStringy(userJson);//用户信息
				m.setIntx(replies.size());//评论总数
				//获取每层的用户信息
				mList.add(m);
			}
		}
		
		return mList;
	}
		

	/**
	 * 添加新评论
	 * @param reply
	 * @return
	 */
	public Serializable add(Reply reply){
		//新回复是子层回复
		if(reply.getFloorid()!=0){
			return  save(reply);
		}
		//新回复是主层回复
		else{
			Serializable save = super.save(reply);
			reply.setFloorid((Integer) save);
			update(reply);
			return save;
		}
		
	}
	
	
	
}
