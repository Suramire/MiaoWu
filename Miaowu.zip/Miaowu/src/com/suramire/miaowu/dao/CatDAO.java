package com.suramire.miaowu.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.orm.hibernate3.HibernateTemplate;
import com.suramire.miaowu.bean.CatPhoto;
import com.suramire.miaowu.bean.Catinfo;
import com.suramire.miaowu.bean.M;
import com.suramire.miaowu.bean.Notification;
import com.suramire.miaowu.bean.User;
import com.suramire.miaowu.util.CommonUtil;
import com.suramire.miaowu.util.GsonUtil;

public class CatDAO extends HibernateTemplate {
	
	
	/**
	 * 列出所有猫咪信息
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Catinfo> list(){
		return find("from Catinfo");
	}
	
	/**
	 * 列出所有猫咪信息
	 * @param isAdopted 领养标志位
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Catinfo> list(int isAdopted){
		return find("from Catinfo c where c.isAdopted=?",new Object[]{isAdopted});
	}
	
	/**
	 * 列出所有的猫咪配图
	 * @param noteId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<String> getAllPictureById(int catId){
		List<String> list = new ArrayList<String>();
		List<CatPhoto> temp  =find("from CatPhoto cp where cp.cid=?",new Object[]{catId});
		for (CatPhoto catphoto : temp) {
			list.add(catphoto.getName());
		}
		return list;
	}
	
	/**
	 * 列出已被领养的猫
	 * @param uid
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Catinfo> getAdoptedCat(int uid){
		return find("from Catinfo c where c.isAdopted=1 and uid=?",new Object[]{uid});
	}
	
	/**
	 * 列出所有待审核的请求
	 * M 包括 猫咪信息 申请者姓名
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<M> listppliedCat(){
		List<M> mList = new ArrayList<M>();
		List<Catinfo> find = find("from Catinfo c where c.isAdopted=0 and uid!=0");
		if(find.size()!=0){
			for (int i = 0; i < find.size(); i++) {
				M m = new M();
				Catinfo catinfo = find.get(i);
				m.setStringy(GsonUtil.objectToJson(catinfo));//设置信息体携带猫咪信息
				User user = super.get(User.class, catinfo.getUid());//获取申请者的信息
				String nickname = user.getNickname();
				m.setStringx(nickname);
				mList.add(m);
			}
		}
		return mList;
	}
	
	/**
	 * 审核领养信息
	 * @param cid
	 * @param flag
	 * @return
	 */
	public boolean reviewApplyCat(int cid,int flag){
		boolean result = false;
		try{
			Notification notification = new Notification();
			Catinfo catinfo = super.get(Catinfo.class, cid);
			catinfo.setIsAdopted(flag);
			if(flag==1){
				catinfo.setAdddate(new Date());
				notification.setContent("恭喜你，你申请领养No."+catinfo.getId()+" 已被批准");
			}else{
				notification.setContent("很遗憾，你申请领养No."+catinfo.getId()+" 已被拒绝");
			}
			notification.setTime(CommonUtil.getTimeStamp());
			notification.setUid1(0);//代表系统通知
			notification.setUid2(catinfo.getUid());//通知的目标用户
			notification.setIsread(0);
			notification.setType(4);//代表请求结果的通知
			super.save(notification);
			if(flag!=1){
				catinfo.setUid(0);//将猫咪的状态置未待领养
			}
			catinfo.setAdoptdate(new Date());
			super.update(catinfo);
			result = true;
		}catch(Exception e){
			result = false;
		}
		return result;
	}
	
	/**
	 * 申请领养
	 * @param cid
	 * @param uid
	 * @return
	 */
	public boolean applyCat(int cid,int uid){
		boolean flag = false;
		Catinfo catinfo = super.get(Catinfo.class, cid);
		//已有人申请则不进行申请
		if(catinfo.getUid()==null || catinfo.getUid()==0){
			catinfo.setUid(uid);//申请者编号
			catinfo.setAdddate(new Date());//申请的时间
			super.update(catinfo);
			flag = true;
			Notification notification = new Notification();
			notification.setContent("有人向你发送了一个领养请求,查看详情");
			notification.setTime(CommonUtil.getTimeStamp());
			notification.setUid1(cid);//此时存放的是领养记录的编号
			notification.setUid2(1);//通知的目标用户
			notification.setIsread(0);
			notification.setType(3);//3代表领养请求的通知
			super.save(notification);
		}
		return flag;
	}
}
